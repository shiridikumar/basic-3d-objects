#include <glm/gtx/matrix_cross_product.hpp>

int main()
{
	int Error(0);

	return Error;
}
